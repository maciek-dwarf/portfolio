// Fill out your copyright notice in the Description page of Project Settings.

#include "SimulationTest.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, SimulationTest, "SimulationTest" );
