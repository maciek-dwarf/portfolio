from wave_file_manager import wave_file_read_samples, wave_file_write_samples
from exclude_silence_processing import get_samples_without_silences



input_filename = "test1.wav"
#input_filename = "test_glitch.wav"

wav_samples = wave_file_read_samples(input_filename)
if wav_samples == None:
    print("Error: Failed reading given wav - incorrect number of samples")
    exit(0)


wav_samples_without_silences = get_samples_without_silences(wav_samples)


output_filename = input_filename[:-4] + "_OUT" + input_filename[-4:]
print("OUTPUT FILENAME", output_filename)
wave_file_write_samples(output_filename, wav_samples_without_silences)

