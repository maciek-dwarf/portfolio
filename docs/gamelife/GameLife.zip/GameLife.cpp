﻿#include <iostream>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <string>
#include <sstream>
#include <utility>
#include <climits>

using namespace std;

// ============================================================================
// HASH FUNCTION FOR pair<T1, T2>
// ============================================================================
// Custom hash function for std::pair to use in unordered_set/unordered_map.
// Uses hash_combine algorithm (similar to Boost) for excellent distribution.
// ============================================================================

struct hash_pair {
    template <class T1, class T2>
    size_t operator()(const std::pair<T1, T2>& p) const {
        // Hash the first element
        size_t hash1 = hash<T1>{}(p.first);

        // Hash the second element
        size_t hash2 = hash<T2>{}(p.second);

        // Combine the two hash values using hash_combine algorithm
        // 0x9e3779b9 is a magic constant (golden ratio) that helps mix bits
        // Bit shifts (<< 6, >> 2) further improve bit mixing
        return hash1 ^ (hash2 + 0x9e3779b9 + (hash1 << 6) + (hash1 >> 2));
    }
};

// Type alias for long long
using ll = long long;

// ============================================================================
// CONWAY'S GAME OF LIFE STATE MANAGER
// ============================================================================
// Implements Conway's Game of Life with support for very large coordinates
// (signed 64-bit range). Uses Life 1.06 format for input/output.
// ============================================================================

class GameOfLifeState {
public:
    // ========================================================================
    // CONSTRUCTOR
    // ========================================================================
    // Reads initial state from standard input in Life 1.06 format.
    // Format: First line "#Life 1.06", then lines of "x y" coordinates.
    // ========================================================================

    GameOfLifeState() {
        aliveCells = readInput();
    }

    // ========================================================================
    // COMPUTE NEXT GENERATION
    // ========================================================================
    // Applies Conway's Game of Life rules:
    // 1. Live cell survives if it has 2 or 3 live neighbors
    // 2. Dead cell becomes alive if it has exactly 3 live neighbors
    // 
    // Returns: Number of alive cells in the next generation
    // ========================================================================

    size_t getNextGameOfLifeState() {
        // Set to store alive cells that survive to next generation
        // (cells with 2 or 3 alive neighbors)
        std::unordered_set<std::pair<ll, ll>, hash_pair> survivedAliveCells;

        // Map to count how many alive neighbors each dead cell has
        // Key: dead cell coordinate, Value: count of alive neighbors
        std::unordered_map<std::pair<ll, ll>, int, hash_pair> resurrectedCandidateCells;

        // Process each alive cell
        for (const auto& cell : aliveCells) {
            // Get all 8 neighbors of this cell
            vector<pair<ll, ll>> neighbours = getNeighbours(cell);

            // Count how many of these neighbors are alive
            int aliveNeighboursCount = 0;

            for (const auto& neighbour : neighbours) {
                if (aliveCells.count(neighbour) == 1) {
                    // Neighbor is alive - increment count
                    ++aliveNeighboursCount;
                }
                else {
                    // Neighbor is dead - increment its candidate count
                    // This dead cell might be resurrected if it reaches 3
                    resurrectedCandidateCells[neighbour] += 1;
                }
            }

            // Conway's rule: Live cell survives if it has 2 or 3 live neighbors
            if (aliveNeighboursCount == 2 || aliveNeighboursCount == 3) {
                survivedAliveCells.insert(cell);
            }
        }

        // Process dead cells that might be resurrected
        for (const auto& deadCellState : resurrectedCandidateCells) {
            // Conway's rule: Dead cell becomes alive if it has exactly 3 live neighbors
            if (deadCellState.second == 3) {
                survivedAliveCells.insert(deadCellState.first);
            }
        }

        // Update state to next generation
        aliveCells = survivedAliveCells;

        return aliveCells.size();
    }

    // ========================================================================
    // RUN MULTIPLE ITERATIONS
    // ========================================================================
    // Runs the simulation for N generations.
    // 
    // Parameters:
    //   N - Number of iterations to run
    // ========================================================================

    void RunNIteration(int N) {
        for (int i = 0; i < N; ++i) {
            size_t aliveCellsCount = getNextGameOfLifeState();

            // Uncomment to print state after each iteration:
            /* PrintGameOfLifeState();
             cout << "After " << i + 1 << " iterations: " 
                  << aliveCellsCount << " alive cells" << endl;*/
        }
    }

    // ========================================================================
    // PRINT CURRENT STATE
    // ========================================================================
    // Prints the current state in Life 1.06 format to standard output.
    // Format: First line "#Life 1.06", then lines of "x y" coordinates.
    // ========================================================================

    void PrintGameOfLifeState() {
        // Print Life 1.06 format header
        cout << "#Life 1.06" << endl;

        // Print each alive cell's coordinates
        for (const auto& cell : aliveCells) {
            cout << cell.first << " " << cell.second << endl;
        }
    }

private:
    // ========================================================================
    // SAFE ADDITION HELPER
    // ========================================================================
    // Safely adds two long long values, checking for overflow/underflow.
    // 
    // Parameters:
    //   a - First value
    //   b - Second value (can be negative)
    //   result - Output parameter for the result
    // 
    // Returns:
    //   true if addition is safe, false if overflow/underflow would occur
    // ========================================================================

    inline bool safeAdd(ll a, ll b, ll& result) {
        if (b > 0) {
            // Adding positive value - check for overflow
            // Overflow occurs if: a + b > LLONG_MAX
            // Rearranged: a > LLONG_MAX - b
            if (a > LLONG_MAX - b) {
                return false;  // Would overflow
            }
        }
        else if (b < 0) {
            // Adding negative value - check for underflow
            // Underflow occurs if: a + b < LLONG_MIN
            // Rearranged: a < LLONG_MIN - b
            if (a < LLONG_MIN - b) {
                return false;  // Would underflow
            }
        }
        // b == 0 is always safe

        result = a + b;
        return true;
    }

    // ========================================================================
    // GET NEIGHBORS OF A CELL
    // ========================================================================
    // Returns all 8 neighbors of a given cell (Moore neighborhood).
    // Handles overflow/underflow at LLONG_MAX and LLONG_MIN boundaries.
    // 
    // Parameters:
    //   cell - The cell to get neighbors for
    // 
    // Returns:
    //   Vector of neighbor coordinates (may be less than 8 if at boundaries)
    // ========================================================================

    std::vector<std::pair<ll, ll>> getNeighbours(const std::pair<ll, ll>& cell) {
        std::vector<std::pair<ll, ll>> neighbours;
        neighbours.reserve(8);  // Reserve space for 8 neighbors (optimization)

        // All 8 possible neighbor offsets (Moore neighborhood):
        // Top-left, top-right, bottom-left, bottom-right,
        // Right, top, bottom, left
        std::vector<std::pair<ll, ll>> neighboursDiff{
            {1, 1},   // Top-right
            {-1, 1},  // Top-left
            {1, -1},  // Bottom-right
            {-1, -1}, // Bottom-left
            {1, 0},   // Right
            {0, 1},   // Top
            {0, -1},  // Bottom
            {-1, 0}   // Left
        };

        // Compute each neighbor safely
        for (const auto& diff : neighboursDiff) {
            ll newX, newY;

            // Only add neighbor if both coordinates are safe (no overflow/underflow)
            if (safeAdd(cell.first, diff.first, newX) &&
                safeAdd(cell.second, diff.second, newY)) {
                neighbours.push_back({ newX, newY });
            }
            // Otherwise, skip this neighbor (would cause overflow/underflow)
        }

        return neighbours;
    }

    // ========================================================================
    // READ INPUT FROM STANDARD INPUT
    // ========================================================================
    // Reads Life 1.06 format from standard input.
    // 
    // Format:
    //   First line: "#Life 1.06" (header, optional)
    //   Subsequent lines: "x y" (coordinates of live cells)
    //   Empty lines and lines starting with '#' are ignored
    // 
    // Returns:
    //   Set of alive cell coordinates
    // ========================================================================

    std::unordered_set<std::pair<ll, ll>, hash_pair> readInput() {
        std::unordered_set<std::pair<ll, ll>, hash_pair> cells;
        std::string line;

        // Read all lines from standard input
        while (std::getline(std::cin, line)) {
            // Skip empty lines and comment lines (including header)
            if (line.empty() || line[0] == '#') {
                continue;
            }

            // Parse two integers (x and y coordinates)
            std::istringstream iss(line);
            ll x, y;
            if (iss >> x >> y) {
                // Successfully parsed - add cell to set
                cells.insert({ x, y });
            }
            // If parsing fails, skip the line (invalid format)
        }

        return cells;
    }

    // ========================================================================
    // MEMBER VARIABLES
    // ========================================================================

    // Set of currently alive cells (coordinates)
    std::unordered_set<std::pair<ll, ll>, hash_pair> aliveCells;
};

// ============================================================================
// MAIN FUNCTION
// ============================================================================
// Entry point: Reads initial state, runs 10 iterations, prints final state.
// ============================================================================

int main() {
    // Create game state (reads initial state from stdin)
    GameOfLifeState game;

    // Run simulation for 10 generations
    game.RunNIteration(10);

    // Print final state in Life 1.06 format
    game.PrintGameOfLifeState();

    return 0;
}